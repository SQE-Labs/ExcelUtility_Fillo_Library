package com.demo.fillo.FilloPOC;



public class FilloDemo {

	public static void main(String[] args) throws Exception {
		 ExcelUtility excel = new ExcelUtility();
		 excel.selectAllUsers();
		 excel.insertUser("rahul", "Rahul@321");
		 excel.selectUserWithWhere("rahul");
		 excel.updatePassword("rahul", "Updated@321");
		 excel.selectUserWithLike("s"); // matches 'surjeet', 'shiv'
		 excel.selectAllUsers();
		 excel.simulateDelete("rahul");
		 excel.selectAllUsers();
		    
		 excel.closeConnection();

	}
	
	
}
