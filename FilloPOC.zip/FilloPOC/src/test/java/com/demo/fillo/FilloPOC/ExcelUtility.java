package com.demo.fillo.FilloPOC;

import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

public class ExcelUtility {
	 private Connection conn;
	 
	 public ExcelUtility() {
	        try {
	            Fillo fillo = new Fillo();
	            this.conn = fillo.getConnection("LoginData.xlsx");
	        } catch (Exception e) {
	            System.err.println("Failed to establish connection: " + e.getMessage());
	        }
	    }
	 
	 public void closeConnection() {
	        if (conn != null) conn.close();
	    }
	 
	 
	public void selectAllUsers() throws Exception {
		System.out.println("-------- Get All Users ------------");
	    String query = "SELECT * FROM Credentials";
	    Recordset rs = conn.executeQuery(query);
	    while (rs.next()) {
	    	 String username = rs.getField("Username");
	         String password = rs.getField("Password");
	         
	         if (!"Username".equalsIgnoreCase(username) && !username.isEmpty()) {
	             System.out.println("Username: " + username + " | Password: " + password);
	         }
	    }
	    System.out.println("-----------------------------------");
	    rs.close();
	    
	}
	
	public void selectUserWithWhere(String name) throws Exception {
		System.out.println("-------- Get User With Where Condition------------");
	    String query = "SELECT * FROM Credentials WHERE Username='" + name + "'";
	    Recordset rs = conn.executeQuery(query);
	    if (rs.next()) {
	        System.out.println("Password for " + name + ": " + rs.getField("Password"));
	    } else {
	        System.out.println("User not found: " + name);
	    }
	    System.out.println("--------------------------------------------------");
	    rs.close();
	}
	
	public void selectUserWithLike(String pattern) throws Exception {
		System.out.println("-------- Get User With Like ------------");
	    String query = "SELECT * FROM Credentials WHERE Username LIKE '" + pattern + "%'";
	    Recordset rs = conn.executeQuery(query);
	    while (rs.next()) {
	        System.out.println("Match -> Username: " + rs.getField("Username") + " | Password: " + rs.getField("Password"));
	    }
	    System.out.println("---------------------------------------");
	    rs.close();
	}
	
	public void insertUser(String username, String password) throws Exception {
		System.out.println("-------- Insert User ------------");
	    String query = String.format("INSERT INTO Credentials(Username, Password) VALUES('%s','%s')", username, password);
	    conn.executeUpdate(query);
	    System.out.println("Inserted username: " + username);
	    System.out.println("Inserted password: " +password);
	    System.out.println("---------------------------------");
	   
	}
	
	public void updatePassword(String username, String newPassword) throws Exception {
	    System.out.println("-------- Update Password ------------");
	    String query = String.format("UPDATE Credentials SET Password='%s' WHERE Username='%s'", newPassword, username);
	    conn.executeUpdate(query);
	    System.out.println("Updated password for username " +username+ " is: " + newPassword);
	    System.out.println("-------------------------------------");
	}
	
	//Not officially supported, but workaround below
	// Fillo does NOT support DELETE directly, use Excel macro or Apache POI if needed.
	// Otherwise, simulate by updating the row to empty values:
	public void simulateDelete(String username) throws Exception {
		System.out.println("-------- Simulate Delete------------");
	    String query = String.format("UPDATE Credentials SET Username='', Password='' WHERE Username='%s'", username);
	    conn.executeUpdate(query);
	    System.out.println("Simulated delete for: " + username);
	    System.out.println("------------------------------------");
	}

}
